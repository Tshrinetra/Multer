const express = require("express");
const app = express();
const multer = require("multer");
app.use(express.urlencoded({extended:true}))
const storage = multer.diskStorage({
      destination : (req,file,cb)=>{
         console.log(file);
         cb(null,__dirname + "/public");
      },
      filename : (req,file,cb)=>{
           var name = Date.now() + ".jpg"
            cb(null,name);
         }
})
const upload = multer({storage : storage});
app.get("/home",(req,res)=>{
      res.sendFile(__dirname + "/form.html");
})
app.post("/getdata",upload.single("pic"),(req,res)=>{
      console.log(req.body);
res.send("ok");  
})
app.post("/getmul",upload.array("pic",5),(req,res)=>{
      console.log(req.body);
res.send("ok");  
})
app.listen(3000,(err)=>{
      console.log("Server Started");
})